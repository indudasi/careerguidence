# Career Guidance Chatbot - Design Guidelines

## Design Approach
**Utility-Focused Design System Approach** - Using a clean, educational interface inspired by modern learning platforms like Khan Academy and Duolingo. This chatbot prioritizes clarity, accessibility, and ease of use for students seeking career guidance.

## Core Design Elements

### A. Color Palette
**Light Mode:**
- Primary: 217 91% 60% (Professional blue for trust and education)
- Secondary: 217 91% 95% (Light blue for message bubbles)
- Success: 142 76% 36% (Green for positive responses)
- Background: 0 0% 98% (Clean white background)
- Text: 217 19% 27% (Dark blue-gray for readability)

**Dark Mode:**
- Primary: 217 91% 65% (Slightly lighter blue)
- Secondary: 217 91% 15% (Dark blue for message bubbles)
- Success: 142 69% 58% (Lighter green for contrast)
- Background: 217 19% 8% (Deep blue-black)
- Text: 217 19% 85% (Light blue-gray)

### B. Typography
- **Primary Font**: Inter (Google Fonts) - Clean, modern, excellent readability
- **Headings**: Inter Bold (600-700 weight)
- **Body Text**: Inter Regular (400 weight)
- **Chat Messages**: Inter Medium (500 weight) for better distinction

### C. Layout System
**Spacing Units**: Tailwind units of 2, 4, 6, and 8 (p-2, m-4, gap-6, h-8)
- Consistent spacing for chat bubbles, input fields, and navigation
- Generous padding for touch-friendly interactions

### D. Component Library

**Chat Interface:**
- **Message Bubbles**: User messages (right-aligned, primary color), Bot messages (left-aligned, secondary color with subtle shadow)
- **Input Field**: Clean border design with focus states, send button integrated
- **Quick Action Buttons**: Pill-shaped buttons below input for common queries ("B.Tech Jobs", "Govt Exams", "MBA Options")
- **Message History**: Scrollable container with smooth scrolling and fade effects

**Navigation & Layout:**
- **Header**: Simple title with optional help/info icon
- **Main Container**: Centered layout with max-width for optimal reading
- **Footer**: Subtle attribution or additional resources links

**Feedback Elements:**
- **Loading States**: Subtle typing indicators for bot responses
- **Empty States**: Friendly illustration when no messages exist
- **Error States**: Clear, helpful messages for unknown queries with suggested alternatives

### E. Animations
**Minimal, Purposeful Animations:**
- Message appearance: Gentle fade-in from bottom
- Typing indicator: Simple dots animation
- Button interactions: Subtle scale on tap (mobile-friendly)

## Special Considerations

**Student-Friendly Design:**
- Large, easy-to-tap buttons for mobile users
- Clear visual hierarchy for scanning information quickly
- Friendly, approachable tone in visual design
- High contrast ratios for accessibility

**Content Strategy:**
- Bot responses displayed in digestible chunks
- Use bullet points and structured formatting for career options
- Quick action buttons reduce typing for common queries
- Clear categorization of information (degree-specific vs. general guidance)

**Responsive Design:**
- Mobile-first approach (students primarily use phones)
- Chat interface optimized for portrait orientation
- Touch-friendly interaction areas (minimum 44px touch targets)

This design creates a professional yet approachable experience that helps students feel confident while exploring their career options, with clear information hierarchy and intuitive interactions.