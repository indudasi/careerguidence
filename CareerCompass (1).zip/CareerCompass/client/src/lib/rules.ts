// Career Guidance FAQ Rules Engine
// Offline-ready rule-based chatbot for career guidance

interface FAQ {
  keywords: string[];
  response: string;
}

const careerFAQs: FAQ[] = [
  // B.Tech Career Options
  {
    keywords: ["btech", "b.tech", "engineering", "computer science", "cse", "mechanical", "electrical", "civil"],
    response: "**Career Options after B.Tech:**\n\n• **Software Developer** - Build applications and software systems\n• **Data Analyst/Scientist** - Analyze data to drive business decisions\n• **Cybersecurity Engineer** - Protect systems from digital threats\n• **Cloud Engineer** - Design and manage cloud infrastructure\n• **Product Manager** - Lead product development and strategy\n• **Higher Studies** - Prepare for GATE, MS abroad, or M.Tech\n\n💡 **Pro tip:** Consider internships during your final year to gain practical experience!"
  },
  
  // B.Com Career Options
  {
    keywords: ["bcom", "b.com", "commerce", "accounting", "finance", "business"],
    response: "**Career Paths after B.Com:**\n\n• **Accountant** - Manage financial records and transactions\n• **Chartered Accountant (CA)** - Professional accounting certification\n• **Banking** - Join banks through entrance exams (IBPS, SBI)\n• **MBA** - Pursue Master's in Business Administration\n• **Corporate Finance** - Work in finance departments of companies\n• **Digital Marketing** - Online marketing and e-commerce\n• **Government Jobs** - SSC, Banking, and other competitive exams\n\n📈 **Trending:** Financial technology (FinTech) roles are growing rapidly!"
  },
  
  // B.Sc Career Options
  {
    keywords: ["bsc", "b.sc", "science", "physics", "chemistry", "biology", "mathematics", "botany", "zoology"],
    response: "**Opportunities after B.Sc:**\n\n• **Higher Studies** - M.Sc., Ph.D. for research careers\n• **Teaching** - School teacher or lecturer with B.Ed/M.Ed\n• **Research** - Work in labs, ISRO, DRDO, or private R&D\n• **Data Science** - Especially for Maths/Statistics graduates\n• **Pharmaceutical** - Quality control, research in pharma companies\n• **Government Exams** - UPSC, SSC, Banking, Railways\n• **Healthcare** - Medical coding, lab technician roles\n\n🔬 **Growth Area:** Biotechnology and environmental science offer excellent prospects!"
  },
  
  // B.A Career Options
  {
    keywords: ["ba", "b.a", "arts", "humanities", "english", "history", "political science", "sociology", "psychology"],
    response: "**Career Options after B.A:**\n\n• **Civil Services** - UPSC, State PSC for administrative roles\n• **SSC Exams** - Central government jobs\n• **Journalism** - Media, content writing, digital journalism\n• **Law** - Pursue LLB for legal career\n• **Social Work** - NGOs, community development\n• **Teaching** - With B.Ed for school teaching\n• **Content Creation** - Writing, editing, digital marketing\n• **Higher Studies** - M.A., competitive exam preparation\n\n✍️ **Emerging Field:** Content creation and digital media offer great freelance opportunities!"
  },
  
  // MBA Career Options
  {
    keywords: ["mba", "management", "masters business", "post graduation"],
    response: "**Career Paths after MBA:**\n\n• **Management Consultant** - Advise companies on strategy\n• **Investment Banking** - Financial analysis and deals\n• **Product Manager** - Lead product development\n• **Marketing Manager** - Brand management and campaigns\n• **Operations Manager** - Optimize business processes\n• **HR Manager** - Talent acquisition and management\n• **Entrepreneur** - Start your own business\n• **Business Analyst** - Data-driven business insights\n\n🚀 **High Growth:** Tech companies offer excellent MBA opportunities!"
  },
  
  // Government Exams
  {
    keywords: ["government", "govt", "exam", "upsc", "ssc", "banking", "railway", "defense", "nda", "cds", "psc"],
    response: "**Popular Government Exams:**\n\n**Central Government:**\n• **UPSC** - Civil Services (IAS, IPS, IFS)\n• **SSC** - Central government departments\n• **Banking** - IBPS, SBI, RBI for bank jobs\n• **Railways** - RRB for railway positions\n• **Defense** - NDA, CDS, AFCAT for armed forces\n\n**State Level:**\n• **State PSC** - State government positions\n• **State Police** - Police constable to officer ranks\n• **Teaching** - TET, CTET for government schools\n\n📚 **Preparation tip:** Start early and follow a consistent study schedule!"
  },
  
  // Scholarships
  {
    keywords: ["scholarship", "financial aid", "gate fellowship", "aicte", "funding", "stipend"],
    response: "**Scholarships & Financial Aid:**\n\n**After Engineering:**\n• **GATE Fellowship** - For M.Tech/Ph.D. studies\n• **AICTE Scholarships** - Merit-based financial support\n• **State Government Schemes** - Check your state's education portal\n\n**General Scholarships:**\n• **Merit-cum-Means** - Based on academic performance and income\n• **Minority Scholarships** - For specific communities\n• **Girl Child Education** - Special schemes for female students\n• **International Studies** - For studying abroad\n\n💰 **Pro tip:** Apply early and keep all documents ready!"
  },
  
  // Career Change & Guidance
  {
    keywords: ["career change", "switch", "guidance", "confused", "what to do", "help", "advice"],
    response: "**Career Guidance Tips:**\n\n**Self Assessment:**\n• Identify your interests and strengths\n• Consider your financial goals\n• Think about work-life balance preferences\n\n**Skill Development:**\n• Take online courses (Coursera, edX, Udemy)\n• Build practical projects\n• Get industry certifications\n\n**Networking:**\n• Connect with professionals on LinkedIn\n• Attend career fairs and seminars\n• Join professional communities\n\n🎯 **Remember:** It's never too late to change direction. Many successful people switched careers!"
  },
  
  // Skills & Preparation
  {
    keywords: ["skills", "prepare", "preparation", "study", "learn", "course", "certification"],
    response: "**Essential Skills for Today's Job Market:**\n\n**Technical Skills:**\n• **Programming** - Python, Java, JavaScript\n• **Data Analysis** - Excel, SQL, Python/R\n• **Digital Marketing** - SEO, social media, analytics\n• **Design** - UI/UX, graphic design tools\n\n**Soft Skills:**\n• **Communication** - Written and verbal\n• **Problem Solving** - Analytical thinking\n• **Leadership** - Team management\n• **Adaptability** - Learning new technologies\n\n📖 **Free Resources:** Khan Academy, YouTube, government skill portals!"
  }
];

const fallbackResponses: string[] = [
  "I understand you're looking for career guidance! I can help with questions about:\n• Career options after B.Tech, B.Com, B.Sc, B.A, MBA\n• Government exam information\n• Scholarship opportunities\n• Career change advice\n\nTry asking something like 'What jobs after B.Tech in CSE?' or 'Tell me about government exams'.",
  
  "I'm here to guide your career journey! You can ask me about:\n• Specific degree career paths\n• Government job opportunities\n• Higher education options\n• Skill development suggestions\n\nWhat specific career area would you like to explore?",
  
  "Let me help you with your career planning! I have information about:\n• Post-graduation job opportunities\n• Competitive exam preparation\n• Professional development paths\n• Educational scholarships\n\nFeel free to ask about any particular field or degree!"
];

const greetingResponses: string[] = [
  "Hello! 👋 I'm your Career Guidance Bot. I'm here to help students explore career options after 12th grade and college. What would you like to know about your career path?",
  
  "Welcome! I can provide guidance on career opportunities after various degrees like B.Tech, B.Com, B.Sc, B.A, MBA, and information about government exams. How can I assist you today?",
  
  "Hi there! Ready to explore your career options? I have comprehensive information about job opportunities, higher studies, and competitive exams. What's on your mind?"
];

// Main function to get response based on user input
export function getResponse(userInput: string): string {
  if (!userInput || userInput.trim().length === 0) {
    return "Please ask me something about your career path! I'm here to help.";
  }
  
  const input = userInput.toLowerCase().trim();
  
  // Check for greetings
  const greetingKeywords = ["hello", "hi", "hey", "good morning", "good afternoon", "good evening", "start", "begin"];
  if (greetingKeywords.some(keyword => input.includes(keyword))) {
    return greetingResponses[Math.floor(Math.random() * greetingResponses.length)];
  }
  
  // Check against FAQ keywords
  for (const faq of careerFAQs) {
    if (faq.keywords.some(keyword => input.includes(keyword))) {
      return faq.response;
    }
  }
  
  // Return fallback response
  return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
}

// Quick action suggestions
export const quickActions: string[] = [
  "What jobs after B.Tech?",
  "B.Com career options",
  "Government exams",
  "MBA opportunities", 
  "B.Sc career paths",
  "B.A job options",
  "Scholarship information",
  "Career change advice"
];

// Helper function to get a random greeting
export function getGreeting(): string {
  return greetingResponses[Math.floor(Math.random() * greetingResponses.length)];
}