import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Send, GraduationCap } from "lucide-react";
import { getResponse, getGreeting } from "@/lib/rules";
import MessageBubble from "./MessageBubble";
import QuickActionButtons from "./QuickActionButtons";
import ThemeToggle from "./ThemeToggle";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: string;
}

export default function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Send initial greeting message
    const welcomeMessage: Message = {
      id: "welcome",
      text: getGreeting(),
      isUser: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages([welcomeMessage]);
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const addMessage = (text: string, isUser: boolean) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      isUser,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleSendMessage = async (messageText?: string) => {
    const textToSend = messageText || inputValue.trim();
    if (!textToSend) return;

    // Add user message
    addMessage(textToSend, true);
    setInputValue("");
    setIsLoading(true);

    // Simulate thinking time for better UX
    setTimeout(() => {
      const botResponse = getResponse(textToSend);
      addMessage(botResponse, false);
      setIsLoading(false);
      
      // Focus back to input
      setTimeout(() => inputRef.current?.focus(), 100);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickAction = (action: string) => {
    handleSendMessage(action);
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto bg-background">
      {/* Header */}
      <Card className="border-b rounded-none bg-card/50 backdrop-blur-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-primary" data-testid="icon-graduation-cap" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground" data-testid="text-app-title">
                Career Guidance Bot
              </h1>
              <p className="text-sm text-muted-foreground" data-testid="text-app-subtitle">
                Your path to career success
              </p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </Card>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full p-8">
            <div className="text-center text-muted-foreground">
              <GraduationCap className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium mb-2">Welcome to Career Guidance Bot</p>
              <p className="text-sm">Ask me anything about your career path!</p>
            </div>
          </div>
        ) : (
          <div className="space-y-1" data-testid="container-messages">
            {messages.map((message) => (
              <MessageBubble
                key={message.id}
                message={message.text}
                isUser={message.isUser}
                timestamp={message.timestamp}
              />
            ))}
            {isLoading && (
              <div className="flex gap-3 p-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <GraduationCap className="w-4 h-4 text-primary" />
                </div>
                <div className="bg-muted/50 rounded-lg px-4 py-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-muted-foreground/60 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2 h-2 bg-muted-foreground/60 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2 h-2 bg-muted-foreground/60 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <QuickActionButtons onQuickAction={handleQuickAction} disabled={isLoading} />

      {/* Input Area */}
      <Card className="border-t rounded-none bg-card/50 backdrop-blur-sm">
        <div className="p-4">
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about career options, government exams, or get guidance..."
              className="flex-1"
              disabled={isLoading}
              data-testid="input-message"
            />
            <Button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim() || isLoading}
              size="icon"
              className="hover-elevate"
              data-testid="button-send"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2" data-testid="text-input-hint">
            Press Enter to send • This bot works offline with pre-loaded career guidance
          </p>
        </div>
      </Card>
    </div>
  );
}