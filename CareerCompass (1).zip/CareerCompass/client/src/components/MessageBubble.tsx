import { cn } from "@/lib/utils";
import { Bot, User } from "lucide-react";

interface MessageBubbleProps {
  message: string;
  isUser: boolean;
  timestamp?: string;
}

export default function MessageBubble({ message, isUser, timestamp }: MessageBubbleProps) {
  return (
    <div className={cn(
      "flex gap-3 p-4 group",
      isUser ? "justify-end" : "justify-start"
    )}>
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
          <Bot className="w-4 h-4 text-primary" data-testid="icon-bot" />
        </div>
      )}
      
      <div className={cn(
        "max-w-[85%] sm:max-w-[70%] rounded-lg px-4 py-3 shadow-sm",
        isUser 
          ? "bg-primary text-primary-foreground ml-auto" 
          : "bg-muted/50 text-foreground"
      )}>
        <div className="whitespace-pre-wrap text-sm leading-relaxed" data-testid={isUser ? "text-user-message" : "text-bot-message"}>
          {message}
        </div>
        {timestamp && (
          <div className={cn(
            "text-xs mt-2 opacity-70",
            isUser ? "text-primary-foreground/70" : "text-muted-foreground"
          )} data-testid="text-timestamp">
            {timestamp}
          </div>
        )}
      </div>
      
      {isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center">
          <User className="w-4 h-4 text-primary-foreground" data-testid="icon-user" />
        </div>
      )}
    </div>
  );
}