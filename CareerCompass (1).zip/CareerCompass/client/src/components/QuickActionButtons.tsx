import { Button } from "@/components/ui/button";
import { quickActions } from "@/lib/rules";

interface QuickActionButtonsProps {
  onQuickAction: (action: string) => void;
  disabled?: boolean;
}

export default function QuickActionButtons({ onQuickAction, disabled = false }: QuickActionButtonsProps) {
  return (
    <div className="p-4 border-t bg-muted/20">
      <div className="mb-3">
        <h3 className="text-sm font-medium text-muted-foreground" data-testid="text-quick-actions-title">
          Quick Questions
        </h3>
      </div>
      <div className="flex flex-wrap gap-2">
        {quickActions.map((action: string, index: number) => (
          <Button
            key={index}
            variant="outline"
            size="sm"
            onClick={() => onQuickAction(action)}
            disabled={disabled}
            className="text-xs hover-elevate"
            data-testid={`button-quick-action-${index}`}
          >
            {action}
          </Button>
        ))}
      </div>
    </div>
  );
}