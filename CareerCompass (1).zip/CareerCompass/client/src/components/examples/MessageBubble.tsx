import MessageBubble from '../MessageBubble'

export default function MessageBubbleExample() {
  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  return (
    <div className="space-y-4 p-4 bg-background">
      <MessageBubble 
        message="What career options do I have after B.Tech in Computer Science?" 
        isUser={true}
        timestamp={currentTime}
      />
      <MessageBubble 
        message="**Career Options after B.Tech:**

• **Software Developer** - Build applications and software systems
• **Data Analyst/Scientist** - Analyze data to drive business decisions  
• **Cybersecurity Engineer** - Protect systems from digital threats
• **Cloud Engineer** - Design and manage cloud infrastructure

💡 **Pro tip:** Consider internships during your final year to gain practical experience!"
        isUser={false}
        timestamp={currentTime}
      />
    </div>
  )
}