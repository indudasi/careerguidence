import QuickActionButtons from '../QuickActionButtons'

export default function QuickActionButtonsExample() {
  const handleQuickAction = (action: string) => {
    console.log('Quick action triggered:', action);
    alert(`You clicked: "${action}"`);
  };

  return (
    <div className="bg-background">
      <QuickActionButtons onQuickAction={handleQuickAction} />
    </div>
  )
}