import ChatBot from '../ChatBot'

export default function ChatBotExample() {
  return <ChatBot />
}